// Add this script to your Matchday site (index.html), and swap in your
// backend's URL below. This replaces the "notifBtn" click handler from
// the tab-only version — this one gives real push notifications.

const PUSH_SERVER_URL = 'https://your-backend-url.example.com'; // <-- change this after deploying

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map(char => char.charCodeAt(0)));
}

async function enableRealPushNotifications() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    alert('Push notifications aren\'t supported in this browser.');
    return;
  }

  // 1. Register the service worker (must be served from your site's root)
  const registration = await navigator.serviceWorker.register('/sw.js');

  // 2. Ask the user for notification permission
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    alert('Notifications were not enabled.');
    return;
  }

  // 3. Get the backend's public VAPID key
  const { publicKey } = await fetch(`${PUSH_SERVER_URL}/vapid-public-key`).then(r => r.json());

  // 4. Subscribe this browser to push, using that key
  const subscription = await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(publicKey)
  });

  // 5. Send the subscription to the backend so it knows where to push to
  await fetch(`${PUSH_SERVER_URL}/subscribe`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(subscription)
  });

  console.log('Push notifications enabled — this will work even with the site closed.');
}

// Wire this to your existing "Enable live alerts" button, e.g.:
// document.getElementById('notifBtn').addEventListener('click', enableRealPushNotifications);
