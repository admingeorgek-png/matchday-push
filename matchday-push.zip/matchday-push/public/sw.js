// This file must be served from your site's root (e.g. https://yoursite.com/sw.js)
// It runs in the background, separate from any open tab — this is what lets
// notifications arrive even when the site is closed.

self.addEventListener('push', function (event) {
  let data = { title: 'Matchday', body: 'A score just updated.' };
  try {
    data = event.data.json();
  } catch (e) {
    // fall back to default text above if payload isn't JSON
  }

  const options = {
    body: data.body,
    icon: data.icon || '/icon-192.png',
    badge: data.badge || '/icon-192.png',
    vibrate: [100, 50, 100],
    silent: false, // ensures the OS plays its default notification sound
    data: { url: data.url || '/' }
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

// Clicking the notification focuses/opens the site
self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(function (clientList) {
      for (const client of clientList) {
        if (client.url === url && 'focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});
